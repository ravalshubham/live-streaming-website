const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');
const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(express.static(path.join(__dirname, '../public')));

io.on('connection', (socket) => {
    socket.on('join-room', ({ username, room }) => {
        socket.join(room);
    });

    socket.on('stream', ({ room, chunk }) => {
        socket.to(room).emit('stream', { chunk });
    });
});

server.listen(4025, () => console.log('Server running on http://localhost:4025'));