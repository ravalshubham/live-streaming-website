const socket = io();
let stream;
let videoElem = document.getElementById('video');
let startBtn = document.getElementById('startBtn');
let stopBtn = document.getElementById('stopBtn');
let form = document.getElementById('joinForm');
let streamArea = document.getElementById('streamArea');
let roomTitle = document.getElementById('roomTitle');

form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const username = document.getElementById('username').value;
    const room = document.getElementById('room').value;
    socket.emit('join-room', { username, room });
    roomTitle.innerText = `Room: ${room}`;
    form.style.display = 'none';
    streamArea.style.display = 'block';
});

startBtn.onclick = async () => {
    stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
    videoElem.srcObject = stream;
    const mediaRecorder = new MediaRecorder(stream);
    mediaRecorder.ondataavailable = e => {
        socket.emit('stream', { room: roomTitle.innerText.split(": ")[1], chunk: e.data });
    };
    mediaRecorder.start(100);
};

stopBtn.onclick = () => {
    stream.getTracks().forEach(track => track.stop());
    videoElem.srcObject = null;
};
socket.on('stream', ({ chunk }) => {
    const blob = new Blob([chunk], { type: 'video/webm' });
    videoElem.src = URL.createObjectURL(blob);
});